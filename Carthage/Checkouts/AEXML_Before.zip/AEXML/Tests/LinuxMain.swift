import XCTest

import AEXMLTests

var tests = [XCTestCaseEntry]()
tests += AEXMLTests.__allTests()

XCTMain(tests)
