/**
 *  https://github.com/tadija/AEXML
 *  Copyright (c) Marko Tadić 2014-2018
 *  Licensed under the MIT license. See LICENSE file.
 */

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double AEXMLVersionNumber;
FOUNDATION_EXPORT const unsigned char AEXMLVersionString[];
